# MCP Studio

A generic web based ChatGPT plugin starter. The site and the embedded widget share one real MCP server. The browser playground uses deterministic example tools; it does not call an LLM or impersonate ChatGPT.

## Routes

* `/`: playground, tool schemas, resource inspector, connection guide.
* `/api/mcp`: stateless Streamable HTTP MCP, POST JSON-RPC. GET returns 405 because this server does not offer a standalone SSE stream.
* `/widget?mode=web`: standalone browser widget.
* `/resource`: resource metadata and resources/read example.
* MCP resource `ui://starter/dashboard.html`: complete bundled HTML with the standard MCP Apps bridge.

## Run

Use Node 22.13 or later and the pnpm version declared in package.json.

```
pnpm install
node scripts/build-widget.mjs
pnpm dev
pnpm build
```

`show_dashboard` and `open_template_builder` are render tools. `get_examples`, `calculate_estimate`, and `list_embed_templates` return structured data without opening extra cards. All five are read only, deterministic, validated with Zod, and need no API key. Calculator inputs are assumptions, not actual provider pricing or benchmark measurements.

The Templates tab includes five responsive admin dashboard patterns for analytics, commerce, logistics, healthcare, and fintech. Every pattern supports light and dark presentation and includes a direct attribution link to the Dribbble design used as a visual reference. Template metadata lives in `lib/templates.ts` so the website, MCP tools, and embedded UI use one catalog.

The widget uses `@modelcontextprotocol/ext-apps` for initialization, tool result notifications, tool calls, and user initiated followup messages. Server transport uses the official MCP TypeScript SDK. The resource allows no external network or script domains. Host context controls its light or dark theme. The browser preview deliberately selects web mode and calls the same server directly.

## Connect

A remote MCP client must reach `/api/mcp`. A private Sites deployment uses browser access controls, not MCP OAuth: the ChatGPT MCP client cannot reuse the browser session. Intentionally publish this harmless sample for public access, or deploy the source on your own reachable Workers host and add proper MCP authentication before handling private data. Keep private Sites access until the owner chooses a different audience. In ChatGPT developer settings, register the reachable endpoint and ask to show the starter dashboard. Workspace availability varies.

## Customize

Edit `lib/catalog.ts` for tool descriptions, `lib/api/mcp-server.ts` for validated handlers, and `widget/main.ts` plus `widget/template.html` for the embedded UI. Run `node scripts/build-widget.mjs` after widget changes. The main build regenerates it automatically.

No persistent user state, external actions, API keys, or paid inference are included. Add per user authorization, durable storage, distributed rate limits, and audit trails before expanding beyond harmless examples. Readonly annotations inform the host; they are not authorization. HTTP bodies are capped at 32 KiB and browser origins are checked. SDK validation rejects malformed messages and unknown tools.

The download deliberately excludes site identity, credentials, runtime data, node_modules, and build output. Register a new Site when reusing it; never copy another project's hosting identity.

## Verify

```
node scripts/test-mcp.mjs
```

Then open the playground, run each tool, change calculator inputs, and inspect Resources. Final ChatGPT acceptance: connect a reachable endpoint, ask to show the dashboard, then calculate 2000 requests at $0.002 and 250 ms. Expect $4.00 and 500.0 seconds in one interactive card.

Official references:
https://developers.openai.com/plugins/build/chatgpt-ui
https://developers.openai.com/plugins/build/api/mcp-server
https://modelcontextprotocol.io/extensions/apps/overview
